#!/bin/bash
php /var/www/html/app-img/bin/console correo:aviso3dias
php /var/www/html/app-img/bin/console correo:aviso30dias
php /var/www/html/app-img/bin/console correo:aviso90dias