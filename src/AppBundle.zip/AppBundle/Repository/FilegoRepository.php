<?php

namespace AppBundle\Repository;

use Doctrine\ORM\EntityRepository;

/**
 * Class FilegoRepository
 * @package AppBundle\Repository
 */
class FilegoRepository extends EntityRepository
{


}
