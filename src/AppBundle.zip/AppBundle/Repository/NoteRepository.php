<?php

namespace AppBundle\Repository;

use Doctrine\ORM\EntityRepository;

/**
 * Class NoteRepository
 * @package AppBundle\Repository
 */
class NoteRepository extends EntityRepository
{


}
