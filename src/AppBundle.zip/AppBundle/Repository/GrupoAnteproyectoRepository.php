<?php

namespace AppBundle\Repository;

use Doctrine\ORM\EntityRepository;

/**
 * Class GrupoAnteproyectoRepository
 *
 * @package AppBundle\EntityRepository
 */
class GrupoAnteproyectoRepository extends EntityRepository
{

}