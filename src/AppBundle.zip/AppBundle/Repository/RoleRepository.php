<?php

namespace AppBundle\Repository;

use Doctrine\ORM\EntityRepository;

/**
 * Class RoleRepository
 * @package AppBundle\Repository
 */
class RoleRepository extends EntityRepository
{


}
