<?php

namespace AppBundle\Repository;

use Doctrine\ORM\EntityRepository;

/**
 * Class AccesoRepository
 *
 * @package AppBundle\EntityRepository
 */
class AccesoRepository extends EntityRepository
{


}